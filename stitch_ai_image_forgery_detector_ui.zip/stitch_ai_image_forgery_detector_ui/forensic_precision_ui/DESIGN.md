---
name: Forensic Precision UI
colors:
  surface: '#faf8ff'
  surface-dim: '#d2d9f4'
  surface-bright: '#faf8ff'
  surface-container-lowest: '#ffffff'
  surface-container-low: '#f2f3ff'
  surface-container: '#eaedff'
  surface-container-high: '#e2e7ff'
  surface-container-highest: '#dae2fd'
  on-surface: '#131b2e'
  on-surface-variant: '#464555'
  inverse-surface: '#283044'
  inverse-on-surface: '#eef0ff'
  outline: '#777587'
  outline-variant: '#c7c4d8'
  surface-tint: '#4d44e3'
  primary: '#3525cd'
  on-primary: '#ffffff'
  primary-container: '#4f46e5'
  on-primary-container: '#dad7ff'
  inverse-primary: '#c3c0ff'
  secondary: '#0051d5'
  on-secondary: '#ffffff'
  secondary-container: '#316bf3'
  on-secondary-container: '#fefcff'
  tertiary: '#3130c0'
  on-tertiary: '#ffffff'
  tertiary-container: '#4b4dd8'
  on-tertiary-container: '#d9d8ff'
  error: '#ba1a1a'
  on-error: '#ffffff'
  error-container: '#ffdad6'
  on-error-container: '#93000a'
  primary-fixed: '#e2dfff'
  primary-fixed-dim: '#c3c0ff'
  on-primary-fixed: '#0f0069'
  on-primary-fixed-variant: '#3323cc'
  secondary-fixed: '#dbe1ff'
  secondary-fixed-dim: '#b4c5ff'
  on-secondary-fixed: '#00174b'
  on-secondary-fixed-variant: '#003ea8'
  tertiary-fixed: '#e1e0ff'
  tertiary-fixed-dim: '#c0c1ff'
  on-tertiary-fixed: '#07006c'
  on-tertiary-fixed-variant: '#2f2ebe'
  background: '#faf8ff'
  on-background: '#131b2e'
  surface-variant: '#dae2fd'
typography:
  headline-xl:
    fontFamily: Inter
    fontSize: 32px
    fontWeight: '700'
    lineHeight: 40px
    letterSpacing: -0.02em
  headline-lg:
    fontFamily: Inter
    fontSize: 24px
    fontWeight: '600'
    lineHeight: 32px
    letterSpacing: -0.015em
  headline-md:
    fontFamily: Inter
    fontSize: 18px
    fontWeight: '600'
    lineHeight: 26px
    letterSpacing: -0.01em
  body-lg:
    fontFamily: Inter
    fontSize: 16px
    fontWeight: '400'
    lineHeight: 24px
    letterSpacing: '0'
  body-md:
    fontFamily: Inter
    fontSize: 14px
    fontWeight: '400'
    lineHeight: 20px
    letterSpacing: '0'
  body-sm:
    fontFamily: Inter
    fontSize: 12px
    fontWeight: '400'
    lineHeight: 18px
    letterSpacing: 0.01em
  label-code-lg:
    fontFamily: JetBrains Mono
    fontSize: 14px
    fontWeight: '500'
    lineHeight: 20px
    letterSpacing: -0.01em
  label-code-md:
    fontFamily: JetBrains Mono
    fontSize: 12px
    fontWeight: '500'
    lineHeight: 16px
    letterSpacing: '0'
  label-code-sm:
    fontFamily: JetBrains Mono
    fontSize: 11px
    fontWeight: '500'
    lineHeight: 14px
    letterSpacing: 0.02em
  caption-caps:
    fontFamily: Inter
    fontSize: 11px
    fontWeight: '700'
    lineHeight: 14px
    letterSpacing: 0.06em
rounded:
  sm: 0.125rem
  DEFAULT: 0.25rem
  md: 0.375rem
  lg: 0.5rem
  xl: 0.75rem
  full: 9999px
spacing:
  gutter: 1rem
  gutter-lg: 1.5rem
  margin: 1.5rem
  margin-lg: 2rem
  space-xs: 0.25rem
  space-sm: 0.5rem
  space-md: 0.75rem
  space-lg: 1rem
  space-xl: 1.5rem
  space-2xl: 2rem
---

## Brand & Style
The brand personality embodies forensic rigor, clinical verification, and high-assurance computational analysis. Targeted at digital forensic investigators, legal evidentiary specialists, security researchers, and content authenticity auditors, the interface conveys absolute authority, procedural accuracy, and zero margin for error. 

The aesthetic fuses modern high-density SaaS with forensic instrument engineering. It deliberately avoids flashiness, favoring high-legibility telemetry displays, structured side-by-side artifact inspections (Error Level Analysis heatmaps vs. original tensors), and pristine analytical clarity. The emotional tone evokes calm mastery, surgical certainty, and trusted technological provenance.

## Colors
The system employs a dual-atmosphere paradigm tailored for visual analytical environments: a deep obsidian navy structural anchor paired with a high-clarity slate canvas.

- **Primary & Action Brand Colors:** Electric Indigo (`#4F46E5` default, `#6366F1` hover/active) anchors critical user interactions, model inference invocations, and primary button tiers. Crisp Forensic Blue (`#2563EB`) governs selection tools, active analysis passes, and ELA frequency spectrum toggles.
- **Structural Nav & Chrome:** Vertical sidebar, instrument rails, and deep-inspection metadata bars use Slate 900 (`#0F172A`) and Slate 800 (`#1E293B`) to provide visual ballast and light attenuation when reviewing high-contrast heatmaps.
- **Canvas & Surface Architecture:** Primary canvas rests on ultra-clean Slate 50 (`#F8FAFC`) with structural module backing in Slate 100 (`#F1F5F9`). Workstation cards, data grids, and inspection tiles reside on crisp Pure White (`#FFFFFF`) with deliberate Slate 200 (`#E2E8F0`) borders.
- **Forensic Status & Semantic Accents:**
  - *Authentic / Verified:* Emerald (`#10B981`) denotes validated provenance, zero-tamper integrity, and passing SHA-256 validation.
  - *Manipulated / Anomaly:* Rose (`#EF4444`) flags CNN splice classifications, ELA compression divergence, and injected artifacts.
  - *Indeterminate / Alert:* Amber (`#F59E0B`) indicates high variance, low confidence intervals, or missing EXIF metadata.

## Typography
The system enforces a dual-type hierarchy:

1. **Human Interface & Structural UI (Inter):** Leverages optical sizing and tabular lining figures for interface navigation, headers, status messages, and narrative reports. It delivers neutral, high-legibility text with distinct open counters and legible letterforms.
2. **Technical Telemetry & Evidence Ledger (JetBrains Mono):** Reserved for technical instrumentation, tensor dimensionalities, confidence metrics, cryptographic digests, EXIF tables, and model layer metrics. All tabular numbers, byte offsets, and pixel coordinates are rendered strictly monospaced to prevent horizontal optical shifting during real-time streaming scans.

## Layout & Spacing
The layout employs an asymmetric forensic workstation model built on an 8px base rhythm with a strict 4px micro-grid:

- **Desktop Shell:** Fixed 72px or expandable 240px dark structural sidebar docked to the left canvas, paired with a fluid central stage split into dual or quad viewport grids (Source Artifact vs. ELA Difference Map vs. CNN Heatmap Attention). The right drawer is dedicated to a dense 360px sticky inspector pane displaying telemetry and EXIF tables.
- **Grids & Responsive Behavior:**
  - *Desktop (1280px+):* 12-column fluid grid, 24px margins, 16px to 24px gutters. Center workspace maintains dynamic split-view capability with synchronized pan-and-zoom controls.
  - *Tablet (768px - 1279px):* 8-column layout with inspector docked as an off-canvas drawer or tabbed sub-panel.
  - *Mobile (<768px):* 4-column layout; image comparison switches to vertical stacked panels or touch-based swipe scrubbers.
- **Density:** High-density data zones utilize compact vertical padding (`space-xs` and `space-sm`) to maximize visible information density without cognitive clutter.

## Elevation & Depth
Elevation mimics laboratory precision equipment, relying primarily on crisp low-contrast surface outlines supported by soft, neutral, diffused ambient shadows:

- **Ground Level (Canvas):** Pure `#F8FAFC` base surface, flat with no shadow.
- **Level 1 (Cards, Workstation Tiles, Inspector Panes):** `#FFFFFF` surface bordered with 1px solid `#E2E8F0`. Shadow: `0px 1px 3px rgba(15, 23, 42, 0.04), 0px 1px 2px rgba(15, 23, 42, 0.02)`.
- **Level 2 (Hovered Cards, Dropdowns, Segment Toggles):** Border `#CBD5E1`. Shadow: `0px 4px 6px -1px rgba(15, 23, 42, 0.06), 0px 2px 4px -2px rgba(15, 23, 42, 0.04)`.
- **Level 3 (Modal Analysis Dialogs, Contextual Zoom Lens Overlays):** Border `#94A3B8`. Shadow: `0px 12px 24px -4px rgba(15, 23, 42, 0.08), 0px 4px 8px -2px rgba(15, 23, 42, 0.03)`.
- **Sidebar & Toolstrip Chrome:** Deep Slate `#0F172A` with interior 1px divider in `#1E293B` and no external cast shadow to maintain a flat, anchored baseline.

## Shapes
A conservative, calibrated shape radius (`roundedness: 1` / soft `0.25rem` [4px] base radius) maintains the feel of clinical precision and hardware instrumentation:

- **Buttons, Text Inputs, and Select Boxes:** Fixed 4px corner radius (`rounded`) to communicate crisp boundary enforcement.
- **Panels, Tiles, and Heatmap Viewports:** 6px to 8px maximum (`rounded-lg`) to preserve modular geometric cohesion.
- **Status Pills and Sensor Badges:** Subtle 4px soft corners or full pill treatment strictly when used as telemetry tags (e.g., integrity indicators).
- **Control Dividers & Viewport Splitters:** Hard 0px sharp joins to ensure pixel grid alignment between optical comparator windows.

## Components

### Buttons
- **Primary Action (Run Inference / Export Cryptographic Dossier):** Solid `#4F46E5` background, `#FFFFFF` Inter medium label, 4px border radius. Hover: `#4338CA`. Active: `#3730A3`. Focus: 2px offset ring with `#6366F1`.
- **Secondary (Inspect ELA / Reset Viewport):** Pure white `#FFFFFF` surface, 1px border `#E2E8F0`, text `#0F172A`. Hover: `#F8FAFC` background with border `#CBD5E1`.
- **Destructive / Reject:** Border `#FCA5A5`, text `#DC2626`, background `#FEF2F2`.
- **Monospace Icon Action:** Deep `#0F172A` or `#1E293B` button with monospaced keyboard shortcut badges integrated directly on the right edge.

### Chips & Badges
- **Integrity Status Pills:**
  - *Authentic:* `#ECFDF5` background, `#059669` text, 1px `#A7F3D0` border, leading 6px static status dot.
  - *Manipulated:* `#FEF2F2` background, `#DC2626` text, 1px `#FECACA` border, leading 6px pulsing error dot.
  - *Pending / Scanning:* `#FFFBEB` background, `#D97706` text, 1px `#FDE68A` border.
- **Technical Parameter Chips (e.g., `Quality: 95%`, `Rescale: 1.0x`):** Background `#F1F5F9`, border `#E2E8F0`, text `#475569`, font `JetBrains Mono` 11px.

### Inputs & Select Controls
- Pristine white background, 1px solid `#CBD5E1`, 4px radius. Focus: border `#4F46E5` with `0 0 0 1px #4F46E5`.
- Floating numeric scrubbers and coordinate locators utilize `JetBrains Mono` with embedded increment/decrement stepper triggers.

### Cards & Analytical Panels
- Container: `#FFFFFF` ground, 1px solid `#E2E8F0`, padding `1rem` or `1.5rem`.
- Section Header: Inter 14px bold, upper-case letter-spacing (`0.06em`), text `#64748B`, with bottom border 1px solid `#F1F5F9`.

### Specialized Forensic Components
- **Dual Synchronized Comparator Viewport:** Split-screen or overlay container displaying pristine image vs. Error Level Analysis (ELA) gradient. Accompanied by crosshair synchronization indicators and a floating micro-toolbar containing zoom percentage, channel isolators (RGB/Luminance), and difference-magnitude sliders.
- **Confidence Gauge & Probability Histogram:** Horizontal micro-bars tracking model class activations (e.g., Copy-Move, Splicing, Diffusion Inpainting). Track background `#F1F5F9`, fill mapped dynamically to Semantic Emerald or Semantic Rose based on threshold classification.
- **EXIF Data & Provenance Matrix:** Strict tabular view using `JetBrains Mono` 12px, alternating row fills (`#FFFFFF` to `#F8FAFC`), and truncated copyable SHA-256 hash snippets.